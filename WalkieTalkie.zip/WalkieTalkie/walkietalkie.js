function walkieTalkie() {
  this.channelName = "";
  this.usersList = [];
  this.chat = [];

  this.createChannel = function (newName) {
    this.channelName = newName;
  }

  this.addUserToChannel = function (username) {
    this.usersList.push(username);
  }

  this.addMessage = function (newMessage, username) {
    if (newMessage !== "") {
      this.chat.push({ message: newMessage, username: username });
    }
  }

  this.getChat = function (username) {
    var formattedChat = "";
    for (let i = 0; i < this.chat.length; i++) {
      formattedChat += "<b>" + this.chat[i].username + ": </b>" + this.chat[i].message + "<br />";
    }
    return formattedChat;
  }

  this.getLatestMessage = function () {
    var latestChatItem = this.chat[this.chat.length - 1];

    return latestChatItem ? latestChatItem.username + " said: " + latestChatItem.message : "No messages available";
  }
  return this;
};
